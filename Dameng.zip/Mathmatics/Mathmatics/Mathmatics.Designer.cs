﻿namespace Mathmatics
{
    partial class Mathmatics
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.makeQuestionBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.firstLabel = new System.Windows.Forms.Label();
            this.secondLabel = new System.Windows.Forms.Label();
            this.thirdLabel = new System.Windows.Forms.Label();
            this.answerLabel = new System.Windows.Forms.Label();
            this.plusLabel = new System.Windows.Forms.Label();
            this.multLabel = new System.Windows.Forms.Label();
            this.equalLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.totalTimeLabel = new System.Windows.Forms.Label();
            this.correctTimeLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.thirdPictureBox = new System.Windows.Forms.PictureBox();
            this.secondPictureBox = new System.Windows.Forms.PictureBox();
            this.firstPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // makeQuestionBtn
            // 
            this.makeQuestionBtn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.makeQuestionBtn.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.makeQuestionBtn.Location = new System.Drawing.Point(12, 38);
            this.makeQuestionBtn.Name = "makeQuestionBtn";
            this.makeQuestionBtn.Size = new System.Drawing.Size(174, 43);
            this.makeQuestionBtn.TabIndex = 0;
            this.makeQuestionBtn.Text = "Make a question";
            this.makeQuestionBtn.UseVisualStyleBackColor = true;
            this.makeQuestionBtn.Click += new System.EventHandler(this.makeQuestionBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(133, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Math for Kiwis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 16);
            this.label2.TabIndex = 2;
            // 
            // firstLabel
            // 
            this.firstLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.firstLabel.Location = new System.Drawing.Point(34, 104);
            this.firstLabel.Name = "firstLabel";
            this.firstLabel.Size = new System.Drawing.Size(53, 16);
            this.firstLabel.TabIndex = 3;
            this.firstLabel.Text = "first";
            this.firstLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secondLabel
            // 
            this.secondLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.secondLabel.Location = new System.Drawing.Point(212, 104);
            this.secondLabel.Name = "secondLabel";
            this.secondLabel.Size = new System.Drawing.Size(62, 16);
            this.secondLabel.TabIndex = 3;
            this.secondLabel.Text = "second";
            this.secondLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thirdLabel
            // 
            this.thirdLabel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.thirdLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.thirdLabel.Location = new System.Drawing.Point(364, 104);
            this.thirdLabel.Name = "thirdLabel";
            this.thirdLabel.Size = new System.Drawing.Size(53, 16);
            this.thirdLabel.TabIndex = 3;
            this.thirdLabel.Text = "third";
            this.thirdLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // answerLabel
            // 
            this.answerLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.answerLabel.Location = new System.Drawing.Point(500, 104);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(62, 16);
            this.answerLabel.TabIndex = 3;
            this.answerLabel.Text = "answer";
            this.answerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // plusLabel
            // 
            this.plusLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.plusLabel.Location = new System.Drawing.Point(151, 104);
            this.plusLabel.Name = "plusLabel";
            this.plusLabel.Size = new System.Drawing.Size(17, 16);
            this.plusLabel.TabIndex = 3;
            this.plusLabel.Text = "+";
            // 
            // multLabel
            // 
            this.multLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.multLabel.Location = new System.Drawing.Point(309, 104);
            this.multLabel.Name = "multLabel";
            this.multLabel.Size = new System.Drawing.Size(17, 16);
            this.multLabel.TabIndex = 3;
            this.multLabel.Text = "x";
            // 
            // equalLabel
            // 
            this.equalLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.equalLabel.Location = new System.Drawing.Point(446, 106);
            this.equalLabel.Name = "equalLabel";
            this.equalLabel.Size = new System.Drawing.Size(17, 16);
            this.equalLabel.TabIndex = 3;
            this.equalLabel.Text = "=";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 9.216F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(542, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(224, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Oh,math,a piece of cake!";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(219, 250);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(172, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "The Answer is :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox
            // 
            this.textBox.BackColor = System.Drawing.Color.White;
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox.Location = new System.Drawing.Point(417, 249);
            this.textBox.MaxLength = 3;
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(72, 19);
            this.textBox.TabIndex = 5;
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // submitButton
            // 
            this.submitButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.submitButton.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.submitButton.Location = new System.Drawing.Point(231, 290);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(174, 43);
            this.submitButton.TabIndex = 0;
            this.submitButton.Text = "Submit Answer";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(615, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Total time tried:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(615, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(206, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Correct answer times :";
            // 
            // totalTimeLabel
            // 
            this.totalTimeLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.totalTimeLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.totalTimeLabel.Location = new System.Drawing.Point(881, 276);
            this.totalTimeLabel.Name = "totalTimeLabel";
            this.totalTimeLabel.Size = new System.Drawing.Size(53, 16);
            this.totalTimeLabel.TabIndex = 3;
            this.totalTimeLabel.Text = "total";
            this.totalTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // correctTimeLabel
            // 
            this.correctTimeLabel.Font = new System.Drawing.Font("Times New Roman", 9.216F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.correctTimeLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.correctTimeLabel.Location = new System.Drawing.Point(863, 317);
            this.correctTimeLabel.Name = "correctTimeLabel";
            this.correctTimeLabel.Size = new System.Drawing.Size(71, 16);
            this.correctTimeLabel.TabIndex = 3;
            this.correctTimeLabel.Text = "correct";
            this.correctTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Mathmatics.Properties.Resources.cake;
            this.pictureBox1.Location = new System.Drawing.Point(642, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(292, 206);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // thirdPictureBox
            // 
            this.thirdPictureBox.Image = global::Mathmatics.Properties.Resources._1;
            this.thirdPictureBox.Location = new System.Drawing.Point(343, 139);
            this.thirdPictureBox.Name = "thirdPictureBox";
            this.thirdPictureBox.Size = new System.Drawing.Size(108, 89);
            this.thirdPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.thirdPictureBox.TabIndex = 6;
            this.thirdPictureBox.TabStop = false;
            // 
            // secondPictureBox
            // 
            this.secondPictureBox.Image = global::Mathmatics.Properties.Resources._1;
            this.secondPictureBox.Location = new System.Drawing.Point(180, 139);
            this.secondPictureBox.Name = "secondPictureBox";
            this.secondPictureBox.Size = new System.Drawing.Size(108, 89);
            this.secondPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.secondPictureBox.TabIndex = 6;
            this.secondPictureBox.TabStop = false;
            // 
            // firstPictureBox
            // 
            this.firstPictureBox.Image = global::Mathmatics.Properties.Resources._1;
            this.firstPictureBox.Location = new System.Drawing.Point(12, 139);
            this.firstPictureBox.Name = "firstPictureBox";
            this.firstPictureBox.Size = new System.Drawing.Size(108, 89);
            this.firstPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.firstPictureBox.TabIndex = 6;
            this.firstPictureBox.TabStop = false;
            // 
            // Mathmatics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 366);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.thirdPictureBox);
            this.Controls.Add(this.secondPictureBox);
            this.Controls.Add(this.firstPictureBox);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.correctTimeLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.totalTimeLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.thirdLabel);
            this.Controls.Add(this.secondLabel);
            this.Controls.Add(this.equalLabel);
            this.Controls.Add(this.multLabel);
            this.Controls.Add(this.plusLabel);
            this.Controls.Add(this.firstLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.makeQuestionBtn);
            this.MaximizeBox = false;
            this.Name = "Mathmatics";
            this.Text = "Learning Mathmatics";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button makeQuestionBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label firstLabel;
        private System.Windows.Forms.Label secondLabel;
        private System.Windows.Forms.Label thirdLabel;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.Label plusLabel;
        private System.Windows.Forms.Label multLabel;
        private System.Windows.Forms.Label equalLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label totalTimeLabel;
        private System.Windows.Forms.Label correctTimeLabel;
        private System.Windows.Forms.PictureBox firstPictureBox;
        private System.Windows.Forms.PictureBox secondPictureBox;
        private System.Windows.Forms.PictureBox thirdPictureBox;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

